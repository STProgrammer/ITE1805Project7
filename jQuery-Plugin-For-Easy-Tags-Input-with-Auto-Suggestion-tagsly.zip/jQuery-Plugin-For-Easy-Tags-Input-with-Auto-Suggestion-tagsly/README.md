tagsly
======

Tagsly is a jQuery plugin for easily creating a tag textbox. It aims to be minimal and easy to edit so you can style it however you want.
